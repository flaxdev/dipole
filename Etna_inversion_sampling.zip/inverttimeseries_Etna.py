# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 10:53:25 2023

@author: flavio.cannavo@ingv.it
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import glob
import os
from pyproj import Proj
from dpmodel import dipole, mogi
from tqdm import tqdm

NANVALUE = -999999

# Parameters and ranges that go into Monte Carlo simulations 
maxdepth = -10000 # m
maxvolume = 10
maxhypervolume = 100
MULTIPLICATIVEFACTOR = 365
windays = 200
spatialrange = 6000 # m

coord_ranges = np.array([[-spatialrange, -spatialrange, maxdepth], [spatialrange, spatialrange, 0]])
azim_range = [0, 90]
azenith_range = [0, 10]
hypervolume_range = np.array([0.05, maxhypervolume])*1e9
kappa_range = [-1, 1]
volume_range = np.array([0.05, maxvolume])*1e7

def loaddata(folder):
    DATA = None
    
    for file in glob.glob(f"{folder}/*.csv"):
        station = os.path.split(file)[-1].split('.')[0]
        data = pd.read_csv(file, names=['time','e','n','u'])
        data['time'] = data['time'].apply(np.floor)
        data.set_index('time',inplace=True)
        
        cols = pd.MultiIndex.from_product([[station],['e','n','u']], names=["station", "component"])
        data.columns = cols
        DATA = data if DATA is None else pd.concat([DATA,data], axis=1)
    
    positions = DATA.loc[0]
    DATA = DATA.drop(0)
    DATA.sort_index(inplace=True)
    
    toUTM = Proj("+proj=utm +zone=33 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs")
    
    for station, pos in positions.groupby(level='station'):
        x,y = toUTM(positions[station,'e'], positions[station,'n'])
        positions[station,'e'] = x
        positions[station,'n'] = y
        
    positions = positions.unstack(level=1)    
   
    return DATA, positions
    
def np_slope(x):
    idx = np.isfinite(x.values) & (x.values!=NANVALUE)
    return np.polyfit(x.index.values[idx],
                      x.values[idx],1)[0]

def np_slope_errors(x):
    # return\ 1
    idx = np.isfinite(x.values) & (x.values!=NANVALUE)
    x, cov = np.polyfit(x.index.values[idx],
                      x.values[idx],1,cov=True)
    return np.sqrt(cov[0,0])



def AICs(n, mse, num_params):
    aic = n * np.log(mse) + 2 * num_params
    aic_c = aic + (2*num_params*(num_params+1))/(n - num_params - 1)
    return  aic, aic_c


def getdefofield(data, windays):
    
  data = data.copy()
  data.fillna(NANVALUE, inplace=True)
  defofield = data.rolling(windays, min_periods=int(windays/2)).apply(np_slope)
  defofielderror = data.rolling(windays, min_periods=int(windays/2)).apply(np_slope_errors)
  
  defofielderror.columns = defofielderror.columns.set_levels(['se','sn','su'],level=1)
  defofield = pd.concat([defofield,defofielderror], axis=1)
  
  defofield.dropna(how='all', inplace=True)
  
  return defofield


def invert4dipole(dfield, coords, coord_ranges, azim_range,
                  azenith_range, hypervolume_range, kappa_range, algo):
    
    dfield = dfield.copy()
    dfield.dropna(axis=1, how='all', inplace=True)
    
    displacements = dfield.loc(axis=1)[(slice(None),['e','n','u'])].T.unstack(level=1).values
    displerrors = dfield.loc(axis=1)[(slice(None),['se','sn','su'])].T.unstack(level=1).values
    points = coords.loc[dfield.columns.unique(level='station')].values

    displacements *= MULTIPLICATIVEFACTOR
    displerrors *= MULTIPLICATIVEFACTOR
    
    source = dipole.invert(points, displacements, coord_ranges, azim_range, azenith_range, hypervolume_range, kappa_range, displerrors=displerrors,
                              alg=algo, err='wrmse')

    mse = source.misfit(points=points, displacements=displacements, displerrors=displerrors)
    
    k = 5
    n = np.prod(displacements.shape)
    
    bic = n * np.log(mse) + k*np.log(n)
    aic = AICs(n, mse, k)
    
    source.hypervolume /= MULTIPLICATIVEFACTOR

    return mse, aic[0], aic[1] , bic, source

def invert4mogi(dfield, coords, coord_ranges, volume_range, algo):
    
    dfield = dfield.copy()
    dfield.dropna(axis=1, how='all', inplace=True)
    
    displacements = dfield.loc(axis=1)[(slice(None),['e','n','u'])].T.unstack(level=1).values
    displerrors = dfield.loc(axis=1)[(slice(None),['se','sn','su'])].T.unstack(level=1).values
    points = coords.loc[dfield.columns.unique(level='station')].values
    
    displacements *= MULTIPLICATIVEFACTOR
    displerrors *= MULTIPLICATIVEFACTOR
    
    source = mogi.invert(points, displacements, coord_ranges, volume_range, displerrors=displerrors,
                              alg=algo, err='wrmse')

    mse = source.misfit(points=points, displacements=displacements, displerrors=displerrors)
    
    k = 4
    n = np.prod(displacements.shape)
    
    bic = n * np.log(mse) + k*np.log(n)
    aic = AICs(n, mse, k)
    
    source.volume /= MULTIPLICATIVEFACTOR
    
    return mse, aic[0], aic[1] , bic, source

  
    
if __name__ == '__main__':
    
    # algorithm to be variated in the Monte Carlo simulation
    algo = 'shgo'
    
    # load time series data
    data, positions = loaddata('data')
       
    # barycentered
    coords = positions - [positions.mean().values[0], positions.mean().values[1], 0]
    
    # calculate the defo field
    defofield = getdefofield(data, windays)
    
    
    # collect results
    RESULTS = []    
    for index, row in tqdm(defofield.iterrows(), total=len(defofield)):
        
       
        sdipo = invert4dipole(row.to_frame().T, coords, coord_ranges, azim_range,
                      azenith_range, hypervolume_range, kappa_range, algo)
    
        smogi = invert4mogi(row.to_frame().T, coords, coord_ranges, volume_range, algo)
        
        results = [index, sdipo[0], smogi[0], sdipo[1], smogi[1], sdipo[2], smogi[2],
                        sdipo[3], smogi[3], sdipo[4].coord[0], sdipo[4].coord[1], sdipo[4].coord[2], 
                        sdipo[4].azenith, sdipo[4].azim, sdipo[4].hypervolume, sdipo[4].kappa,
                        smogi[4].coord[0], smogi[4].coord[1], smogi[4].coord[2]]
        RESULTS.append(results)
        
    results = pd.DataFrame(np.array(RESULTS), columns=['time','mse dip','mse mogi','AIC dipole',
            'AIC mogi', 'AICc dipole', 'AICc mogi', 'BIC dipole', 'BIC mogi',
            'X dipole','Y dipole','Z dipole', 'Zenith dipole','Azim dipole','HVol dipole', 'K dipole',
            'X mogi','Y mogi','Z mogi'])
    
    
    fig, axes = plt.subplots(nrows=2, ncols=1, sharex=True)
    
    g = results[['AICc dipole','AICc mogi']].plot(color = ['#BB0000', '#0000BB'], title='Model Selection vs Time', ax=axes[0])
    
    x_axis = g.axes.get_xaxis()
    x_axis.set_visible(False)
    
    idipol = results['AICc dipole'] < results['AICc mogi']
    imogi = results['AICc dipole'] >= results['AICc mogi']
    
    axes[1].scatter(results[['Z dipole']].loc[idipol].index.values, results[['Z dipole']].loc[idipol].values, color='#BB0000')
    axes[1].scatter(results[['Z mogi']].loc[imogi].index.values, results[['Z mogi']].loc[imogi].values, color='#0000BB')   
    axes[1].set_ylabel('m b.s.l.')
    
    fig.autofmt_xdate()
    
    plt.subplots_adjust(wspace=0, hspace=0)
    
    plt.tight_layout()


      
